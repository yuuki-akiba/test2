/**
 * 
 */
package batchprot;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author 
 *
 */
public class ApiExecute {
	
	final static String PROP_KEY_FILE_INPUT_PATH = "file.input.path";
	final static String PROP_KEY_FILE_INPUT_NAME_URIUP = "file.input.name.uriup";
	final static String PROP_KEY_FILE_INPUT_NAME_URIDWN = "file.input.name.uridwn";

	/**
	 * @param args
	 */
	public static void main(String[] args) {

        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.S");
        System.out.println("Start : " + sdf.format(date));
		
        HttpRequestCall api = new HttpRequestCall();
        
		try {
			
	    	Map<String, String> param = new HashMap<>();
			
	    	param.put("tenantId", "medicaldevice");
	    	param.put("userId", "medicaldevice0101");
	    	param.put("password", "operator010120220725");
	    	param.put("client_id", "gQOWZxF3vgOG2N1GpoGdX49E43nKthXL");
	    	param.put("response_type", "token");
	    	param.put("redirect_uri", "");
			
			// アクセストークン取得
	    	String token = api.postAuth(param);
	    		    	
			int apiType = 2;
			
			if(apiType == 1) {
				// 入力ファイルからパラメータ取得
				String jsonStr = jsonToString(PropertyUtil.getProperty(PROP_KEY_FILE_INPUT_NAME_URIUP));

				// ファイルアップロードAPI呼出し
				api.postUriUpload(token, jsonStr);
			}else {
				// 入力ファイルからパラメータ取得
				String jsonStr = jsonToString(PropertyUtil.getProperty(PROP_KEY_FILE_INPUT_NAME_URIDWN));

				// ファイルダウンロードAPI呼出し
				api.postUriDownload(token, jsonStr);
			}
		} catch (IOException | InterruptedException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

        date = new Date();
        System.out.println("End   : " + sdf.format(date));
	}
	
	static String jsonToString(String fileName) {
	
		String jsonStr = "";

		try {
	    	Path path1 = Paths.get(PropertyUtil.getProperty(PROP_KEY_FILE_INPUT_PATH), fileName);
	        ObjectMapper om = new ObjectMapper();
	        JsonNode jsonNode = null;
	
			jsonNode = om.readTree(path1.toFile());
			jsonStr = om.writeValueAsString(jsonNode);
		} catch (JsonProcessingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return jsonStr;
	}

}
