/**
 * 
 */
package batchprot;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ProxySelector;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class HttpRequestCall {
	

	final static String PROP_KEY_URI_HOST = "uri.host";
	final static String PROP_KEY_URI_PATH_AUTH = "uri.path.auth";
	final static String PROP_KEY_URI_PATH_URIUPLOAD = "uri.path.uriupload";
	final static String PROP_KEY_URI_PATH_URIDOWNLOAD = "uri.path.uridownload";
	final static String PROP_KEY_FILE_OUT_PATH = "file.out.path";
	
	
    private final HttpClient httpClient;
    HttpRequestCall() {
//        this.httpClient = HttpClient.newHttpClient();
        this.httpClient = HttpClient.newBuilder()
        .proxy(ProxySelector.of(new InetSocketAddress("proxygate2.nic.nec.co.jp", 8080)))
        .build();
    }

    HttpRequestCall(HttpClient httpClient) {
        this.httpClient = httpClient;
    }

    /**
     * 認証トークン取得(Post)
     */
    public String postAuth(Map<String, ?> param) throws IOException, InterruptedException {
    	
    	String token = "";

    	StringBuilder uriStr = new StringBuilder();
    	uriStr.append("https://m01005-p.apimng.com/medicaldevice/auth") ; 
    	uriStr.append("?tenantId=").append(param.get("tenantId"));
    	uriStr.append("&userId=").append(param.get("userId"));
    	uriStr.append("&password=").append(param.get("password"));
    	uriStr.append("&client_id=").append(param.get("client_id"));
    	uriStr.append("&response_type=").append(param.get("response_type"));
    	uriStr.append("&redirect_uri=").append(param.get("redirect_uri"));

    	HttpRequest httpRequest = HttpRequest.newBuilder(URI.create(uriStr.toString()))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(""))
                .build();

        HttpResponse<String> httpResponse = this.httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
//        System.out.println(httpResponse.body());
        
        ObjectMapper mapper = new ObjectMapper();
        JsonNode jsonResult = mapper.readTree(httpResponse.body());
        System.out.println("access_token : " + jsonResult.get("access_token").asText());
        
        token = jsonResult.get("access_token").asText();
        
        return token;
        
    }

    /**
     * URIアップロード(Post)
     */
    public void postUriUpload(String token, String jsonStr) throws IOException, InterruptedException {
    	
    	String strAuthParam = "Bearer " + token;

    	StringBuilder uriStr = new StringBuilder();
    	uriStr.append(PropertyUtil.getProperty(PROP_KEY_URI_HOST)).append(PropertyUtil.getProperty(PROP_KEY_URI_PATH_URIUPLOAD)) ; 

    	HttpRequest httpRequest = HttpRequest.newBuilder(URI.create(uriStr.toString()))
                .header("Content-Type", "application/json")
                .header("Authorization", strAuthParam)
                .POST(HttpRequest.BodyPublishers.ofString(jsonStr))
                .build();

        HttpResponse<String> httpResponse = this.httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        System.out.println("httpResponse.statusCode() : " + httpResponse.statusCode());
        System.out.println("httpResponse.body() :" + httpResponse.body());
    }

    /**
     * URIダウンロード(Post)
     */
    public void postUriDownload(String token, String jsonStr) throws IOException, InterruptedException {
    	
    	String strAuthParam = "Bearer " + token;

    	StringBuilder uriStr = new StringBuilder();
    	uriStr.append(PropertyUtil.getProperty(PROP_KEY_URI_HOST)).append(PropertyUtil.getProperty(PROP_KEY_URI_PATH_URIDOWNLOAD)) ; 

    	HttpRequest httpRequest = HttpRequest.newBuilder(URI.create(uriStr.toString()))
                .header("Content-Type", "application/json")
                .header("Authorization", strAuthParam)
                .POST(HttpRequest.BodyPublishers.ofString(jsonStr))
                .build();

        HttpResponse<String> httpResponse = this.httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        System.out.println("httpResponse.statusCode() : " + httpResponse.statusCode());
        System.out.println("httpResponse.body() :" + httpResponse.body());
        ObjectMapper objectMapper = new ObjectMapper();

        String outFile = PropertyUtil.getProperty(PROP_KEY_FILE_OUT_PATH) + "uridownload.json";
        Map<String, Object> map 
        	= objectMapper.readValue(httpResponse.body(), new TypeReference<Map<String,Object>>(){});    
        objectMapper.writeValue(new File(outFile), map);
    }
}