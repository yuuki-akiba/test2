package com.example.demo.action;

import static com.example.demo.common.SipLogger.*;

import java.io.IOException;
import java.io.OutputStream;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.JsonConverter;
import com.example.demo.api.HttpRequestCall;
import com.example.demo.common.MessageUtil;
import com.example.demo.model.AuthData;
import com.example.demo.model.InfomationData;
import com.example.demo.model.SearchItem;
import com.example.demo.model.UriDownloadForm;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class UriDownloadAction {
	private final InfomationData infoData;
	private final MessageUtil msgUtil;
	private final AuthData authData;

	//	@Autowired
	public UriDownloadAction(InfomationData infoData, MessageUtil msgUtil, AuthData authData) {
		this.infoData = infoData;
		this.authData = authData;
		this.msgUtil = msgUtil;
	}

	public String initiaized(Model model) {

		LOGGER_TRACE_START();

		UriDownloadForm form = new UriDownloadForm();
		model.addAttribute("form", form);
		model.addAttribute("infoData", infoData);
		form.setGetStatus("2");

		// 検索用パラメータ 初期設定
		List<SearchItem> searchItems = new ArrayList<SearchItem>();
		searchItems.add(new SearchItem());
		searchItems.add(new SearchItem());
		searchItems.add(new SearchItem());
		form.setSearchItems(searchItems);

		LOGGER_TRACE_END();

		return "uridown";
	}

	public String execute(UriDownloadForm form, Model model, HttpServletResponse response) {

		LOGGER_TRACE_START();

		model.addAttribute("form", form);
		model.addAttribute("infoData", infoData);

		HttpResponse<String> res = null;
		HttpRequestCall api = new HttpRequestCall();

		try {
			Map<String, String> param = new HashMap<>();
			// セッション情報の認証情報をセット
			param.put("userId", authData.getUserId());
			param.put("password", authData.getPassword());

			// アクセストークン取得
			String token = "";
			res = api.postAuth(param);

			if (res.statusCode() == api.STSCD_AUTH_SUCCESS) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode jsonResult = mapper.readTree(res.body());
				LOGGER(DEBUG, "access_token : " + jsonResult.get("access_token").asText());

				// 認証トークン
				token = jsonResult.get("access_token").asText();

				// リクエストパラメータ編集
				JsonConverter jsonConv = new JsonConverter();
				String jsonStr = jsonConv.getUriDownloadJsonStr(form);

				// ファイルアップロードAPI呼出し
				res = api.postUriDownload(token, jsonStr);
//				if (res.statusCode() == 200 || res.statusCode() == 201) {
				if (res.statusCode() == 200) {
					LOGGER(INFO, msgUtil.GET_MESSAGE("N004001"));
					infoData.setData(infoData.getMSG_TYPE_NORMAL(), msgUtil.GET_MESSAGE("N004001"));

					try (OutputStream os = response.getOutputStream();) {

						Map<String, Object> resBodyMap = jsonConv.jsonStrToMap(res.body());

						List<Map<String, Object>> downloadDataList = (List<Map<String, Object>>) resBodyMap
								.get("download_data_list");

						StringBuffer sb = new StringBuffer();

						for (Map<String, Object> map : downloadDataList) {
							sb.append(map.get("download_data"));
//							System.out.println("response.downloadDataList[n] :" + map.get("download_data"));
							LOGGER(DEBUG, "response.downloadDataList[n] :" + map.get("download_data"));
						}

						byte[] fb1 = sb.toString().getBytes("UTF-8");

						Date date = new Date();
						SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
						String outFileName = "uri_download_" + sdf.format(date) + ".txt";

						response.setContentType("application/octet-stream");
						response.setHeader("Content-Disposition", "attachment; filename=" + outFileName);
						response.setHeader("Set-Cookie", "fileDownload=true; path=/");
						response.setContentLength(fb1.length);
						os.write(fb1);
						os.flush();

						LOGGER_TRACE_END();

						return null;
					} catch (IOException e) {
//						e.printStackTrace();
						LOGGER_STACKTRACE(ERROR, "response.getOutputStream エラー", e);
					}

				} else {
					// API実行ステータスコードエラー
					LOGGER(WARN, msgUtil.GET_MESSAGE("E001001", "URIダウンロード", res.statusCode(), res.body()));
					infoData.setData(infoData.MSG_TYPE_ERROR,
							msgUtil.GET_MESSAGE("E001001", "URIダウンロード", res.statusCode(), res.body()));
				}
			} else {
				// 認証エラー
				if (res.statusCode() == api.STSCD_AUTH_FAILED) {
					LOGGER(WARN, msgUtil.GET_MESSAGE("W001003"));
					infoData.setData(infoData.MSG_TYPE_WARN, msgUtil.GET_MESSAGE("W001003"));
					// 認証APIステータスコードエラー
				} else {
					LOGGER(WARN, msgUtil.GET_MESSAGE("E001001", "認証API", res.statusCode(), res.body()));
					infoData.setData(infoData.MSG_TYPE_ERROR,
							msgUtil.GET_MESSAGE("E001001", "認証API", res.statusCode(), res.body()));
				}
			}
		} catch (IOException | InterruptedException e) {
			// TODO 自動生成された catch ブロック
//			e.printStackTrace();
			LOGGER_STACKTRACE(ERROR, "例外発生", e);
		}

		LOGGER_TRACE_END();

		return "uridown";
	}

}
