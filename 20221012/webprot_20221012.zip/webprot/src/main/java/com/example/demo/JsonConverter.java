package com.example.demo;

import static com.example.demo.common.SipLogger.*;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import com.example.demo.model.DbDownloadForm;
import com.example.demo.model.DbUploadForm;
import com.example.demo.model.SearchItem;
import com.example.demo.model.UriDownloadForm;
import com.example.demo.model.UriUploadForm;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonConverter {

    public String getUriUploadJsonStr(UriUploadForm form) {

		LOGGER_TRACE_START();
        String jsonStr = "";

        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, String> searchItemsMap = new HashMap<String, String>();
        String eachDataFlagStr = "";

        map.put("conv_rule_id", form.getConvRuleId());
        map.put("data_type", form.getDataType());
        map.put("src_location_code", form.getSrcLocationCode());
        map.put("dst_location_code", form.getDstLocationCode());

        String uploadDataStr = "";
        if (form.getUploadDataType().equals("1")) {
            try {
                uploadDataStr = new String(form.getUploadDataFile().getBytes());
            } catch (IOException e) {
                // TODO 自動生成された catch ブロック
                e.printStackTrace();
            }
        }else {
            uploadDataStr = form.getUploadDataText();
        }
        map.put("upload_data", uploadDataStr);

        if ("true".equals(form.getEachDataFlag())) {
            eachDataFlagStr = "True";
        } else {
            eachDataFlagStr = "False";
        }
        map.put("each_data_flag", eachDataFlagStr);
        for (SearchItem item : form.getSearchItems()) {
            searchItemsMap.put(item.getKey(), item.getValue());
        }
        //		map.put("search_items", searchItemsMap);
        if (form.getUpdateUri() != null) {
            map.put("update_uri", form.getUpdateUri());
        }
        if (form.getUpdateReqParam() != null) {
            map.put("update_req_param", form.getUpdateReqParam());
        }

        try {
            jsonStr = new ObjectMapper().writeValueAsString(map);
        } catch (JsonProcessingException e) {
            // TODO 自動生成された catch ブロック
            e.printStackTrace();
        }

        LOGGER_TRACE_END();

        return jsonStr;

    }

    public String getUriDownloadJsonStr(UriDownloadForm form) {

		LOGGER_TRACE_START();

        String jsonStr = "";

        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, String> searchItemsMap = new HashMap<String, String>();
        String eachDataFlagStr = "";

        map.put("conv_rule_id", form.getConvRuleId());
        map.put("data_type", form.getDataType());
        map.put("src_location_code", form.getSrcLocationCode());
        map.put("dst_location_code", form.getDstLocationCode());
        map.put("get_status", form.getGetStatus());

        map.put("from_create_datetime", form.getFromCreateDateTime());
        map.put("to_create_datetime", form.getToCreateDateTime());

        if ("true".equals(form.getEachDataFlag())) {
            eachDataFlagStr = "True";
        } else {
            eachDataFlagStr = "False";
        }
        map.put("each_data_flag", eachDataFlagStr);
        for (SearchItem item : form.getSearchItems()) {
            searchItemsMap.put(item.getKey(), item.getValue());
        }
        if (form.getUpdateUri() != null) {
            map.put("update_uri", form.getUpdateUri());
        }
        if (form.getUpdateReqParam() != null) {
            map.put("update_req_param", form.getUpdateReqParam());
        }

        try {
            jsonStr = new ObjectMapper().writeValueAsString(map);
        } catch (JsonProcessingException e) {
            // TODO 自動生成された catch ブロック
            e.printStackTrace();
        }

		LOGGER_TRACE_END();

		return jsonStr;

    }

    public String getDbDownloadJsonStr(DbDownloadForm form) {

		LOGGER_TRACE_START();

        String jsonStr = "";
        Charset charset = StandardCharsets.UTF_8;
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, String> searchItemsMap = new HashMap<String, String>();
        String eachDataFlagStr = "";

        map.put("conv_rule_id", form.getConvRuleId());
        map.put("data_type", form.getDataType());
        map.put("src_location_code", form.getSrcLocationCode());
        map.put("dst_location_code", form.getDstLocationCode());
        map.put("get_status", form.getGetStatus());

        map.put("from_create_datetime", form.getFromCreateDateTime());
        map.put("to_create_datetime", form.getToCreateDateTime());

        if ("true".equals(form.getEachDataFlag())) {
            eachDataFlagStr = "True";
            map.put("select_uri", form.getSelectUri());
            
            String whereStr = "";
            // 初期値設定
            if(null == form.getSelectReqParam4() || "".equals(form.getSelectReqParam4())){
                whereStr = "1=1";
            }else {
                whereStr = form.getSelectReqParam4();
            }
            byte[] whereByte = Base64.getEncoder()
                    .encode(whereStr.getBytes(charset));
                String whereB64Str = new String(whereByte, charset); 
            map.put("select_req_param", form.getSelectReqParam1() + " " + form.getSelectReqParam2() + " "
                                            + form.getSelectReqParam3() + " " + whereB64Str);
            map.put("update_uri", form.getUpdateUri());
            map.put("update_req_param", form.getUpdateReqParam());
        } else {
            eachDataFlagStr = "False";
        }
        map.put("each_data_flag", eachDataFlagStr);
        
        map.put("update_conv_rule_id", form.getUpdateConvRuleId());
        
        for (SearchItem item : form.getSearchItems()) {
            searchItemsMap.put(item.getKey(), item.getValue());
        }
        if (form.getUpdateUri() != null) {
            map.put("update_uri", form.getUpdateUri());
        }
        if (form.getUpdateReqParam() != null) {
            map.put("update_req_param", form.getUpdateReqParam());
        }

        // Mapオブジェクト→Json String
        try {
            jsonStr = new ObjectMapper().writeValueAsString(map);
        } catch (JsonProcessingException e) {
            // TODO 自動生成された catch ブロック
            e.printStackTrace();
        }

		LOGGER_TRACE_END();

        return jsonStr;
    }

    public Map<String, Object> jsonStrToMap(String jsonStr) {

		LOGGER_TRACE_START();

        Map<String, Object> map = new HashMap<String, Object>();

        ObjectMapper mapper = new ObjectMapper();
        try {
            map = mapper.readValue(jsonStr, new TypeReference<Map<String, Object>>(){});
        } catch (JsonMappingException e) {
            // TODO 自動生成された catch ブロック
            e.printStackTrace();
            return null;
        } catch (JsonProcessingException e) {
            // TODO 自動生成された catch ブロック
            e.printStackTrace();
            return null;
        }
        
		LOGGER_TRACE_END();

        return map;
    }
    
    public String getDbUploadJsonStr(DbUploadForm form) {

		LOGGER_TRACE_START();
        String jsonStr = "";
        Charset charset = StandardCharsets.UTF_8;

        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, String> searchItemsMap = new HashMap<String, String>();
        String eachDataFlagStr = "";

        map.put("conv_rule_id", form.getConvRuleId());
        map.put("data_type", form.getDataType());
        map.put("src_location_code", form.getSrcLocationCode());
        map.put("dst_location_code", form.getDstLocationCode());

        String uploadDataStr = "";
        if (form.getUploadDataType().equals("1")) {
            try {
                uploadDataStr = new String(form.getUploadDataFile().getBytes());
            } catch (IOException e) {
                // TODO 自動生成された catch ブロック
                e.printStackTrace();
            }
        }else {
            uploadDataStr = form.getUploadDataText();
        }
        map.put("upload_data", uploadDataStr);

        if ("true".equals(form.getEachDataFlag())) {
            eachDataFlagStr = "True";
            map.put("update_uri", form.getUpdateUri());

        for (SearchItem item : form.getSearchItems()) {
            searchItemsMap.put(item.getKey(), item.getValue());
        }
        String whereStr = "";
        byte[] whereByte = Base64.getEncoder()
                .encode(whereStr.getBytes(charset));
            String whereB64Str = new String(whereByte, charset); 
        map.put("update_req_param", form.getUpdateReqParam1() + " " + form.getUpdateReqParam2() + " "
                                  + form.getUpdateReqParam3() + " " + whereB64Str);
        
        map.put("select_uri", form.getSelectUri());
        map.put("select_req_param", form.getSelectReqParam());
        } else {
            eachDataFlagStr = "False";
        }
        map.put("each_data_flag", eachDataFlagStr);
        
        map.put("update_conv_rule_id", form.getUpdateConvRuleId());
                
        //		map.put("search_items", searchItemsMap);
        if (form.getSelectUri() != null) {
            map.put("select_uri", form.getSelectUri());
        }
        if (form.getSelectReqParam() != null) {
            map.put("select_req_param", form.getSelectReqParam());
        }

        try {
            jsonStr = new ObjectMapper().writeValueAsString(map);
        } catch (JsonProcessingException e) {
            // TODO 自動生成された catch ブロック
            e.printStackTrace();
        }

        LOGGER_TRACE_END();

        return jsonStr;

    }
}
