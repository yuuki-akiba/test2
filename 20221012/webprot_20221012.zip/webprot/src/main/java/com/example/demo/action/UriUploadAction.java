package com.example.demo.action;

import static com.example.demo.common.SipLogger.*;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.JsonConverter;
import com.example.demo.api.HttpRequestCall;
import com.example.demo.common.MessageUtil;
import com.example.demo.model.AuthData;
import com.example.demo.model.InfomationData;
import com.example.demo.model.SearchItem;
import com.example.demo.model.UriUploadForm;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class UriUploadAction {
	private final InfomationData infoData;
	private final MessageUtil msgUtil;
	private final AuthData authData;

	//	@Autowired
	public UriUploadAction(InfomationData infoData, MessageUtil msgUtil, AuthData authData) {
		this.infoData = infoData;
		this.authData = authData;
		this.msgUtil = msgUtil;
	}

	public String initiaized(Model model) {

		LOGGER_TRACE_START();

		UriUploadForm form = new UriUploadForm();
		model.addAttribute("form", form);
		model.addAttribute("infoData", infoData);

		// アップロードデーターアップロード種別："1"(ファイル)
		form.setUploadDataType("1");

		// 検索用パラメータ 初期設定
		List<SearchItem> searchItems = new ArrayList<SearchItem>();
		searchItems.add(new SearchItem());
		searchItems.add(new SearchItem());
		searchItems.add(new SearchItem());
		form.setSearchItems(searchItems);

		LOGGER_TRACE_END();

		return "uriup";
	}

	public String execute(UriUploadForm form, Model model) {

		LOGGER_TRACE_START();

		model.addAttribute("form", form);
		model.addAttribute("infoData", infoData);

		HttpResponse<String> res = null;
//		JsonConverter jsonConv = new JsonConverter();
//		String jsonStr = jsonConv.getUriUploadJsonStr(form);
		HttpRequestCall api = new HttpRequestCall();

		try {
			Map<String, String> param = new HashMap<>();
			// セッション情報の認証情報をセット
			param.put("userId", authData.getUserId());
			param.put("password", authData.getPassword());

			// アクセストークン取得
			String token = "";
			res = api.postAuth(param);

			// 認証OK
			if (res.statusCode() == api.STSCD_AUTH_SUCCESS) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode jsonResult = mapper.readTree(res.body());
				LOGGER(DEBUG, "access_token : " + jsonResult.get("access_token").asText());

				// 認証トークン
				token = jsonResult.get("access_token").asText();

				// リクエストパラメータ編集
				JsonConverter jsonConv = new JsonConverter();
				String jsonStr = jsonConv.getUriUploadJsonStr(form);

				// ファイルアップロードAPI呼出し
				res = api.postUriUpload(token, jsonStr);
//				if (res.statusCode() == 200 || res.statusCode() == 201) {
				if (res.statusCode() == 201) {
					LOGGER(INFO, msgUtil.GET_MESSAGE("N003001"));
					infoData.setData(infoData.getMSG_TYPE_NORMAL(), msgUtil.GET_MESSAGE("N003001"));
				} else {
					LOGGER(WARN, msgUtil.GET_MESSAGE("E001001", "ｚURIアップロード", res.statusCode(), res.body()));
					infoData.setData(infoData.MSG_TYPE_ERROR, msgUtil.GET_MESSAGE("E001001", "URIアップロード", res.statusCode(), res.body()));
				}
			} else {
				// 認証エラー
				if (res.statusCode() == api.STSCD_AUTH_FAILED) {
					LOGGER(WARN, msgUtil.GET_MESSAGE("W001003"));
					infoData.setData(infoData.MSG_TYPE_WARN, msgUtil.GET_MESSAGE("W001003"));
				// 認証APIステータスコードエラー
				} else {
					LOGGER(WARN, msgUtil.GET_MESSAGE("E001001", "認証", res.statusCode(), res.body()));
					infoData.setData(infoData.MSG_TYPE_ERROR, msgUtil.GET_MESSAGE("E001001", "認証", res.statusCode(), res.body()));
				}
			}
		} catch (IOException | InterruptedException e) {
			LOGGER_STACKTRACE(ERROR, "例外発生", e);
		}

		LOGGER_TRACE_END();

		return "uriup";

	}

}
