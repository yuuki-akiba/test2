package com.example.demo.action;

import static com.example.demo.common.CommonPropertyUtil.*;
import static com.example.demo.common.PropertyUtil.*;
import static com.example.demo.common.SipLogger.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.common.MessageUtil;
import com.example.demo.model.AuthData;
import com.example.demo.model.CommonProperties;
import com.example.demo.model.CommonPropertiesForm;
import com.example.demo.model.InfomationData;

@Service
public class CommonPropertiesAction {

	private final InfomationData infoData;
	private final MessageUtil msgUtil;
	private final AuthData authData;

	//	@Autowired
	public CommonPropertiesAction(InfomationData infoData, MessageUtil msgUtil, AuthData authData) {
		this.infoData = infoData;
		this.authData = authData;
		this.msgUtil = msgUtil;
	}

//	public CommonPropertiesForm initiaized(CommonPropertiesForm form) {
	public String initiaized(Model model) {
		
		LOGGER_TRACE_START();

		CommonPropertiesForm form = new CommonPropertiesForm();
		CommonProperties prop = new CommonProperties();
		
		model.addAttribute("form", form);
		model.addAttribute("infoData", infoData);

		prop.setApiUriHost(GET_PROPERTY(PROP_KEY_API_URI_HOST));

		prop.setAuthApiUriPath(GET_PROPERTY(PROP_KEY_AUTH_API_URI_PATH));
		prop.setAuthApiParamTenantId(GET_PROPERTY(PROP_KEY_AUTH_API_PARAM_TENANT_ID));
		prop.setAuthApiParamClientId(GET_PROPERTY(PROP_KEY_AUTH_API_PARAM_CLIENT_ID));
		prop.setAuthApiParamResponseType(GET_PROPERTY(PROP_KEY_AUTH_API_PARAM_RESPONSE_TYPE));
		prop.setAuthApiParamRedirectUri(GET_PROPERTY(PROP_KEY_AUTH_API_PARAM_REDIRECT_URI));
		
		prop.setUserinfoApiUriPath(GET_PROPERTY(PROP_KEY_USERINFO_API_URI_PATH));

		prop.setComApiUriPathUriupload(GET_PROPERTY(PROP_KEY_COM_API_URI_PATH_URIUPLOAD));
		prop.setComApiUriPathUridownload(GET_PROPERTY(PROP_KEY_COM_API_URI_PATH_URIDOWNLOAD));
		prop.setComApiUriPathDbdownload(GET_PROPERTY(PROP_KEY_COM_API_URI_PATH_DBDOWNLOAD));

		prop.setProxyHost(GET_PROPERTY(PROP_KEY_PROXY_HOST));
		prop.setProxyPort(GET_PROPERTY(PROP_KEY_PROXY_PORT));
		
		form.setProp(prop);

		LOGGER_TRACE_END();

		return "common_properties";
	}

//	public CommonPropertiesForm execute(CommonPropertiesForm form)  {
	public String execute(CommonPropertiesForm form, Model model)  {

//		String resultCd = "0";

		LOGGER_TRACE_START();
		model.addAttribute("form", form);
		model.addAttribute("infoData", infoData);

		Map<String, String> map =  new HashMap<String, String>();
		
		map.put(PROP_KEY_API_URI_HOST, form.getProp().getApiUriHost());
		
		map.put(PROP_KEY_AUTH_API_URI_PATH, form.getProp().getAuthApiUriPath());
		map.put(PROP_KEY_AUTH_API_PARAM_TENANT_ID, form.getProp().getAuthApiParamTenantId());
		map.put(PROP_KEY_AUTH_API_PARAM_CLIENT_ID, form.getProp().getAuthApiParamClientId());
		map.put(PROP_KEY_AUTH_API_PARAM_RESPONSE_TYPE, form.getProp().getAuthApiParamResponseType());
		map.put(PROP_KEY_AUTH_API_PARAM_REDIRECT_URI, form.getProp().getAuthApiParamRedirectUri());
		
		map.put(PROP_KEY_USERINFO_API_URI_PATH, form.getProp().getUserinfoApiUriPath());
		
		map.put(PROP_KEY_COM_API_URI_PATH_URIUPLOAD, form.getProp().getComApiUriPathUriupload());
		map.put(PROP_KEY_COM_API_URI_PATH_URIDOWNLOAD, form.getProp().getComApiUriPathUridownload());
		map.put(PROP_KEY_COM_API_URI_PATH_DBDOWNLOAD, form.getProp().getComApiUriPathDbdownload());
		map.put(PROP_KEY_PROXY_HOST, form.getProp().getProxyHost());
		map.put(PROP_KEY_PROXY_PORT, form.getProp().getProxyPort());

		try {
			outputProperty(PROP_FILE_PATH, map);
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
//			e.printStackTrace();
//			resultCd = "9";
			LOGGER_STACKTRACE(ERROR, "プロパティファイル更新エラー", e);
			LOGGER(WARN, msgUtil.GET_MESSAGE("E002001"));
			infoData.setData(infoData.MSG_TYPE_ERROR, msgUtil.GET_MESSAGE("E002001"));
			return "common_properties";
		}
		
//		form.setResultCd(resultCd);
		LOGGER(INFO, msgUtil.GET_MESSAGE("N002001"));
		infoData.setData(infoData.getMSG_TYPE_NORMAL(), msgUtil.GET_MESSAGE("N002001"));
		
		LOGGER_TRACE_END();

		return "common_properties";

	}

}
