package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class DbDownloadForm {
    // 変換ルールID
	private String convRuleId;
    // 個社形式データフラグ
	private String eachDataFlag;
    // データ種別識別子
	private String dataType;
    // データ取得フラグ
	private String getStatus;
    // 発送元拠点コード
	private String srcLocationCode;
    // 発送先拠点コード
	private String dstLocationCode;
    // 検索範囲の始点日時
	private String fromCreateDateTime;
    // 検索範囲の終点日時
	private String toCreateDateTime;
    // 検索用パラメータ
	private List<SearchItem> searchItems = new ArrayList<SearchItem>();
    // 個社参照コマンド
	private String selectUri;
	// 個社参照コマンド引数1(標準ＭＳＧ情報)
	private String selectReqParam1;
    // 個社参照コマンド引数2(情報区分)
    private String selectReqParam2;
    // 個社参照コマンド引数3(動作指定)
    private String selectReqParam3;
    // 個社参照コマンド引数4(ＷＨＥＲＥ句)
    private String selectReqParam4;
    // 個社更新コマンド
    private String updateUri;
    // 個社更新コマンド引数
    private String updateReqParam;
    // 個社更新変換ルールID
    private String updateConvRuleId;

	// --------------------
	// 画面制御
	// --------------------
//	// API実行結果
//	private String apiResult;
//	// メッセージ情報
//	private String messageInfo;
//	// エラー情報
//	private String errorInfo;
	// submit タイプ
	private String submitType;

}
