package com.example.demo;

import static com.example.demo.common.SipLogger.*;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Webprot2Application {

	public static void main(String[] args) {
		LOGGER_TRACE_START();
		SpringApplication.run(Webprot2Application.class, args);
		LOGGER_TRACE_END();
	}

}
