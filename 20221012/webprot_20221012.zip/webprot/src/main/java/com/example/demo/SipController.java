package com.example.demo;

//import static com.example.demo.common.MessageUtil.*;
import static com.example.demo.common.ValidationPropertyUtil.*;
import static com.example.demo.common.SipLogger.*;

//import java.io.IOException;
//import java.io.OutputStream;
//import java.net.http.HttpResponse;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Locale;
//import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
//import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
//import org.springframework.validation.FieldError;
//import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.action.CommonPropertiesAction;
import com.example.demo.action.DbDownloadAction;
import com.example.demo.action.DbUploadAction;
import com.example.demo.action.LoginAction;
import com.example.demo.action.UriDownloadAction;
import com.example.demo.action.UriUploadAction;
//import com.example.demo.api.HttpRequestCall;
import com.example.demo.common.MessageUtil;
import com.example.demo.model.AuthData;
import com.example.demo.model.CommonPropertiesForm;
import com.example.demo.model.DbDownloadForm;
import com.example.demo.model.DbUploadForm;
import com.example.demo.model.InfomationData;
import com.example.demo.model.LoginForm;
//import com.example.demo.model.SearchItem;
import com.example.demo.model.UriDownloadForm;
import com.example.demo.model.UriUploadForm;
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
//@SessionAttributes(types = LoginForm.class)
@ComponentScan("com.example.demo.action")
@ComponentScan("com.example.demo.model")
public class SipController {

	@Autowired
	private AuthData authData;

	@Autowired
	public InfomationData infoData;
	
//	@Autowired
//	private MessageSource messageSource;
	
//	@Autowired
//	private MessageUtil msgUtil;
//	
	@Autowired
	private LoginAction loginAction;
	@Autowired
	private CommonPropertiesAction commonPropertiesAction;
	@Autowired
	private UriUploadAction uriUploadAction;
	@Autowired
	private UriDownloadAction uriDownloadAction ;
	@Autowired
	private DbUploadAction dbUploadAction;
	@Autowired
	private DbDownloadAction dbDownloadAction ;
	
	

	@GetMapping(value = {"/login", "/login/{option}"})
	public String getLogin(@PathVariable(name = "option", required = false) String option, Model model) {
		LOGGER_TRACE_START();

		String page = loginAction.initiaized(option, model);
		
		LOGGER_TRACE_END();

		return page;
		
	}
		
	@PostMapping(value = "/login")
	public String postLogin( @ModelAttribute @Validated LoginForm form, BindingResult result, Model model) {

		LOGGER_TRACE_START();

		String page = loginAction.execute(form, result, model);

		LOGGER_TRACE_END();

		return page;
	}
	
	
	@RequestMapping(value = "/menu")
	public String menu() {

		LOGGER_TRACE_START();

		LOGGER_TRACE_END();
		return "menu";
	}

	@RequestMapping(value = "/logout")
	public String logout() {

		LOGGER_TRACE_START();
		authData.setUserId("");
		authData.setPassword("");
		LOGGER_TRACE_END();
		return "menu";
	}

	@GetMapping(value = "/uriup")
	public String getUriup(Model model) {
		LOGGER_TRACE_START();
		
		String page = uriUploadAction.initiaized(model);

		LOGGER_TRACE_END();

		return page;
	}

	@PostMapping(value = "/uriup")
	public String postUriup(@ModelAttribute UriUploadForm form, Model model) {
		LOGGER_TRACE_START();

		String page = uriUploadAction.execute(form, model);
		
		LOGGER_TRACE_END();

		return page;
	}

	@GetMapping(value = "/uridown")
	public String getUridwn(Model model) {
		LOGGER_TRACE_START();

		String page = uriDownloadAction.initiaized(model);

		LOGGER_TRACE_END();

		return page;
	}

	@PostMapping(value = "/uridown")
	public String postUridwn(@ModelAttribute UriDownloadForm form, Model model, HttpServletResponse response) {

		LOGGER_TRACE_START();

		String page = uriDownloadAction.execute(form, model, response);

		LOGGER_TRACE_END();

		return page;
	}

	@GetMapping(value = "/dbdown")
	public String getDbdwn(Model model) {
		LOGGER_TRACE_START();
//		DbDownloadForm form = new DbDownloadForm();
//
//		List<SearchItem> searchItems = new ArrayList<SearchItem>();
//		form.setGetStatus("2");
//		form.setEachDataFlag("true");
//
//		searchItems.add(new SearchItem());
//		searchItems.add(new SearchItem());
//		searchItems.add(new SearchItem());
//
//		form.setSearchItems(searchItems);
//		form.setApiResult("");
//
//		model.addAttribute("form", form);
		String page = dbDownloadAction.initiaized(model);

		LOGGER_TRACE_END();

		return page;
	}

	@PostMapping(value = "/dbdown")
	public String postDbdwn(@ModelAttribute DbDownloadForm form, Model model, HttpServletResponse response) {

		LOGGER_TRACE_START();

		String page = dbDownloadAction.execute(form, model, response);
		
		LOGGER_TRACE_END();

		return page;
	}


	@PostMapping(value = "/dbdownlist")
	public String postDbdwnList(@ModelAttribute DbDownloadForm form, Model model, HttpServletResponse response) {

		LOGGER_TRACE_START();

		String page = dbDownloadAction.execute(form, model, response);
		
		LOGGER_TRACE_END();

		return page;
	}
	
	@GetMapping(value = "/comprop")
	public String getCommonProperties(Model model) {
		LOGGER_TRACE_START();

		commonPropertiesAction.initiaized(model);

		LOGGER_TRACE_END();

		return "common_properties";
	}

	@PostMapping(value = "/comprop")
//	public String postCommonProperties(@ModelAttribute CommonPropertiesForm form, Model model,
//			HttpServletResponse response) {
	public String postCommonProperties(@ModelAttribute CommonPropertiesForm form, Model model) {
		LOGGER_TRACE_START();

		model.addAttribute("form", form);

		String page = commonPropertiesAction.execute(form, model);

		LOGGER_TRACE_END();

		return page;
	}

	@GetMapping(value = "/dbup")
	public String getdbup(Model model) {
		LOGGER_TRACE_START();
		
		String page = dbUploadAction.initiaized(model);

		LOGGER_TRACE_END();

		return page;
	}
	
	@PostMapping(value = "/dbup")
	public String postDbup(@ModelAttribute DbUploadForm form, Model model) {
		LOGGER_TRACE_START();

		String page = dbUploadAction.execute(form, model);
		
		LOGGER_TRACE_END();

		return page;
	}
	
}