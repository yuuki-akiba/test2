package com.example.demo.common;

import static com.example.demo.common.SipLogger.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.Map;

public class ValidationPropertyUtil extends PropertyUtil {

	// APIホスト
	public final static String PROP_KEY_API_URI_HOST = "api.uri.host";
	// 認証API
	public final static String PROP_KEY_AUTH_API_URI_PATH = "auth_api.uri.path";
	public final static String PROP_KEY_AUTH_API_PARAM_TENANT_ID = "auth_api.param.tenant_id";
	public final static String PROP_KEY_AUTH_API_PARAM_CLIENT_ID = "auth_api.param.client_id";
	public final static String PROP_KEY_AUTH_API_PARAM_RESPONSE_TYPE = "auth_api.param.response_type";
	public final static String PROP_KEY_AUTH_API_PARAM_REDIRECT_URI = "auth_api.param.redirect_uri";
	// ユーザー情報取得API設定
	public final static String PROP_KEY_USERINFO_API_URI_PATH = "userinfo_api.uri.path";
	// 共通API
	public final static String PROP_KEY_COM_API_URI_PATH_URIUPLOAD = "com_api.uri.path.uriupload";
	public final static String PROP_KEY_COM_API_URI_PATH_URIDOWNLOAD = "com_api.uri.path.uridownload";
	public final static String PROP_KEY_COM_API_URI_PATH_DBDOWNLOAD = "com_api.uri.path.dbdownload";
	// PROXYサーバ
	public final static String PROP_KEY_PROXY_HOST = "proxy.host";
	public final static String PROP_KEY_PROXY_PORT = "proxy.port";
    
    public static final String PROP_FILE_PATH = "resource/validation.properties";
//    private static final Properties properties;

//    private CommonPropertyUtil() throws Exception {
//    	super();
//    }

    static {
    	LOGGER_TRACE_START();
    	LOGGER(DEBUG, "ValidationPropertyUtil static");
//    	super.PROP_FILE_PATH = PROP_FILE_PATH

        loadProperties(PROP_FILE_PATH);
        LOGGER_TRACE_END();
    }

//    /**
//     * 再読み込み
//     *
//     * @param key キー
//     * @return 値
//     */
//    public static void LOAD_PROP() {
//    	LOGGER_TRACE_START();
//        loadProperties(PROP_FILE_PATH);
//        LOGGER_TRACE_END();
//    }

    /**
     * 再読み込み
     *
     * @param key キー
     * @return 値
     */
    public static void reload() {
    	LOGGER_TRACE_START();
        loadProperties(PROP_FILE_PATH);
        LOGGER_TRACE_END();
    }
    
    /**
     * プロパティ値を取得する
     *
     * @param key キー
     * @return 値
     */
    public static String GET_VLDPROP(final String key) {
        return getProperty(key, "");
    }

    /**
     * プロパティ値を取得する
     *
     * @param key キー
     * @param defaultValue デフォルト値
     * @return キーが存在しない場合、デフォルト値
     *          存在する場合、値
     */
    public static String GET_VLDPROP(final String key, final String defaultValue) {
        return getProperty(key, defaultValue);
    }
    
//    
//    /**
//     * プロパティファイルを更新
//     *
//     * @param filepath プロパティファイル
//     * @param map プロパティ設定値
//     * @return 
//     * @throws IOException 
//     */
//    public static void outputProperty(String propfile, Map<String, String> map) throws IOException {
//
//    	LOGGER_TRACE_START();
//
//    	try {
//        	
//        	Path path = Paths.get(propfile);
//            List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
//          
//            String propKey = "";
//            String propValue = "";
//            String mapValue = "";
//            int propDivIndex = 0;
//    		System.out.println("map :" + map );
//    		
//    		int i = 0;
//            for( String line : lines) {
//                propKey = "";
//                propValue = "";
//                mapValue = "";
//
//                propDivIndex = line.indexOf("=");
//            	if(propDivIndex != -1) {
//            		propKey = line.substring(0, propDivIndex);
//            		propValue = line.substring(propDivIndex +1);
//
//            		System.out.println("propKey = " + propKey );
//            		System.out.println("propValue = " + propValue );
//            		
//            		
//            		mapValue = map.get(propKey);
//            		System.out.println("mapValue :" + mapValue );
//            		System.out.println("line before:" + line );
//            		if( mapValue != null ){
//            			lines.set(i, propKey + "=" + mapValue);
//            		}
//            		System.out.println("line after [" +i +"]:" + line );
//            	}
//        		i++;
//            }
//    		System.out.println("lines :" + lines );
//            
//            // 新規で書き込みたいとき
//            Files.write(path, lines, StandardCharsets.UTF_8, StandardOpenOption.WRITE);
//            
//            reload();
//            
//        } catch (IOException e) {
//            e.printStackTrace();
//            throw e;
//        }
//
//    	LOGGER_TRACE_END();
//    }
}