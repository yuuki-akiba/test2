package com.example.demo.action;

import static com.example.demo.common.SipLogger.*;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.JsonConverter;
import com.example.demo.api.HttpRequestCall;
import com.example.demo.common.MessageUtil;
import com.example.demo.model.AuthData;
import com.example.demo.model.DbUploadForm;
import com.example.demo.model.InfomationData;
import com.example.demo.model.SearchItem;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class DbUploadAction {
	private final InfomationData infoData;
	private final MessageUtil msgUtil;
	private final AuthData authData;
	
    //	@Autowired
	public DbUploadAction(InfomationData infoData, MessageUtil msgUtil, AuthData authData) {
		this.infoData = infoData;
		this.authData = authData;
		this.msgUtil = msgUtil;
	}
	
	public String initiaized(Model model) {
		
		LOGGER_TRACE_START();
		
		DbUploadForm form = new DbUploadForm();
		model.addAttribute("form", form);
		model.addAttribute("infoData", infoData);

		List<SearchItem> searchItems = new ArrayList<SearchItem>();
		form.setEachDataFlag("true");
		form.setUploadDataType("1");

		searchItems.add(new SearchItem());
		searchItems.add(new SearchItem());
		searchItems.add(new SearchItem());

		form.setSearchItems(searchItems);

		LOGGER_TRACE_END();

		return "dbup";
	}
	
	public String execute(DbUploadForm form, Model model){
		LOGGER_TRACE_START();
		
		model.addAttribute("form", form);
		model.addAttribute("infoData", infoData);

		HttpResponse<String> res = null;
//		JsonConverter jsonConv = new JsonConverter();
//		String jsonStr = jsonConv.getDbUploadJsonStr(form);
		HttpRequestCall api = new HttpRequestCall();

		try {
			Map<String, String> param = new HashMap<>();
			// セッション情報の認証情報をセット
			param.put("userId", authData.getUserId());
			param.put("password", authData.getPassword());

			// アクセストークン取得
			String token = "";
			res = api.postAuth(param);
			//			if (res.statusCode() == 302) {
			if (res.statusCode() == api.STSCD_AUTH_SUCCESS) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode jsonResult = mapper.readTree(res.body());
				LOGGER(DEBUG, "access_token : " + jsonResult.get("access_token").asText());
				token = jsonResult.get("access_token").asText();

				// リクエストパラメータ編集
				JsonConverter jsonConv = new JsonConverter();
				String jsonStr = jsonConv.getDbUploadJsonStr(form);

				// ファイルアップロードAPI呼出し
				res = api.postUriUpload(token, jsonStr);
//				if (res.statusCode() == 200 || res.statusCode() == 201) {
				if (res.statusCode() == 201) {
					LOGGER(INFO, msgUtil.GET_MESSAGE("N005001"));
					infoData.setData(infoData.getMSG_TYPE_NORMAL(), msgUtil.GET_MESSAGE("N005001"));
				} else {
					// API実行ステータスコードエラー					
					LOGGER(WARN, msgUtil.GET_MESSAGE("E001001", "個社DBアップロード", res.statusCode(), res.body()));
					infoData.setData(infoData.MSG_TYPE_ERROR, msgUtil.GET_MESSAGE("E001001", "個社DBアップロード", res.statusCode(), res.body()));
				}
			} else {
				// 認証エラー
				if (res.statusCode() == api.STSCD_AUTH_FAILED) {
					LOGGER(WARN, msgUtil.GET_MESSAGE("W001003"));
					infoData.setData(infoData.MSG_TYPE_WARN, msgUtil.GET_MESSAGE("W001003"));
				// 認証APIステータスコードエラー
				} else {
					LOGGER(WARN, msgUtil.GET_MESSAGE("E001001", "認証API", res.statusCode(), res.body()));
					infoData.setData(infoData.MSG_TYPE_ERROR, msgUtil.GET_MESSAGE("E001001", "認証API", res.statusCode(), res.body()));
				}
			}
		} catch (IOException | InterruptedException e) {
			// TODO 自動生成された catch ブロック
//			e.printStackTrace();
			LOGGER_STACKTRACE(ERROR, "例外発生", e);
		}
		
		LOGGER_TRACE_END();
		
		return "dbup";
	}
	
}
