package com.example.demo.model;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import lombok.Data;

@Data
@Component
@SessionScope
public class AuthData {
  
	// ログイン状態
//	private boolean isLogin;
	// ユーザID
	private String userId;
	// パスワード
	private String password;
}