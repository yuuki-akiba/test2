package com.example.demo.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class LoginForm {
    // ユーザID
//	@NotBlank(message = "ユーザIDを入力してください")
	@NotBlank(message = "V001001")
//	@Size(min = 1, max = 2, message = "min = 1, max = 2")
//	@Size(max = 2, message = "max = 2")
//	@NotBlank()
	private String userId;
    // パスワード
//	@NotBlank(message = "パスワードを入力してください")
	@NotBlank(message = "V001001")
//	@Size(min = 100, message = "V002001")
//	@Pattern(regexp = "^([\\w])+([\\w\\._-])*\\@([\\w])+([\\w\\._-])*\\.([a-zA-Z])+$", message = "正規表現")
	private String password;
//	// API実行結果
//	private String apiResult;
//	// エラー情報
//	private String errorInfo;
}
