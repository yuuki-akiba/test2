package com.example.demo.model;

import lombok.Data;

@Data
public class CommonProperties {
	// ----------
	// API共通設定
	// ----------
	// URLホスト
	private String apiUriHost;

	// ----------
	// 認証API設定
	// ----------
	// URLパス
	private String authApiUriPath;
	// パラーメータ：テナントID
	private String authApiParamTenantId;
	// パラーメータ：クライアントID（API Key）
	private String authApiParamClientId;
	// パラーメータ：レスポンスタイプ
	private String authApiParamResponseType;
	// パラーメータ：リダイレクトURL
	private String authApiParamRedirectUri;

	// --------------------
	// ユーザー情報取得API設定
	// --------------------
	// URLパス
	private String userinfoApiUriPath;

	// --------------------
	// 共通API設定
	// --------------------
	// URLパス(URIアップロード)
	private String comApiUriPathUriupload;
	// URLパス(URIダウンロード)
	private String comApiUriPathUridownload;
	// URLパス(個社DBダウンロード)
	private String comApiUriPathDbdownload;

	// --------------------
	// Proxyサーバー設定
	// --------------------
	// ホスト
	private String proxyHost;
	// ポート
	private String proxyPort;
	
}
