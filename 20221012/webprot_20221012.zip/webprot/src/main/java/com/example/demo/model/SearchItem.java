package com.example.demo.model;

import lombok.Data;

@Data
public class SearchItem {

    // 検索キー
	private String key;
    // 検索値
    private String value;
}
