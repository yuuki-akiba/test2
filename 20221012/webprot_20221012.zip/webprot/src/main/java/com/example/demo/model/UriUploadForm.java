package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class UriUploadForm {
    // 変換ルールID
	private String convRuleId;
    // 個社形式データフラグ
	private String eachDataFlag;
    // データ種別識別子
	private String dataType;
    // 発送元拠点コード
	private String srcLocationCode;
    // 発送先拠点コード
	private String dstLocationCode;
    // 検索用パラメータ
	private List<SearchItem> searchItems = new ArrayList<SearchItem>();
    // 個社更新コマンド
	private String updateUri;
	// 個社更新コマンド引数
	private String updateReqParam;
	// アップロードデータ 種別
	private String uploadDataType;
	// アップロードデータ ファイル
	private MultipartFile uploadDataFile;
	// アップロードデータ テキスト
	private String uploadDataText;
//	// API実行結果
//	private String apiResult;
//	// エラー情報
//	private String errorInfo;

}
