package com.example.demo.common;

//import static com.example.demo.common.MessageUtil.*;
import static com.example.demo.common.SipLogger.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;

public class PropertyUtil {

    private static final Properties properties;
    
	@Autowired
	private MessageUtil msgUtil;


    protected PropertyUtil()  {
    }

    static {
    	LOGGER_TRACE_START();
    	LOGGER(DEBUG, "PropertyUtil static");
        properties = new Properties();
//        loadProperties();
        LOGGER_TRACE_END();
    }

 
    
//    /**
//     * 再読み込み
//     *
//     * @param key キー
//     * @return 値
//     */
//    public static void reload(String propFile) {
//    	LOGGER_TRACE_START();
//        loadProperties(propFile);
//        LOGGER_TRACE_END();
//    }
//
//    /**
//     * 再読み込み
//     *
//     * @param key キー
//     * @return 値
//     */
//    abstract public void reload() ;

//    /**
//     * プロパティファイル読み込み
//     *
//     * @param 
//     * @return 
//     */
//    public static void loadProperties() {
//        
//    	LOGGER_TRACE_START();
//
////        Date date = new Date();
////        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.S");
////        System.out.println("PropertyUtil loadProperties Start : " + sdf.format(date));
//
//        try {
//            properties.load(Files.newBufferedReader(Paths.get(PROP_FILE_PATH), StandardCharsets.UTF_8));
//        } catch (IOException e) {
//            // ファイル読み込みに失敗
//            System.out.println(String.format("ファイルの読み込みに失敗しました。ファイル名:%s", PROP_FILE_PATH));
//            LOGGER(ERROR, GET_MESSAGE("E0000009",PROP_FILE_PATH));
//        }
//        GET_MESSAGE("N0000009", PROP_FILE_PATH);
//        LOGGER(DEBUG, GET_MESSAGE("N0000009",PROP_FILE_PATH));
////        System.out.println("PropertyUtil loadProperties End   : " + sdf.format(new Date()));
//        
//        LOGGER_TRACE_END();
//    }

    /**
     * プロパティファイル読み込み
     *
     * @param 
     * @return 
     */
    public static void loadProperties(String propFile) {
        
    	LOGGER_TRACE_START();

//        Date date = new Date();
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.S");
//        System.out.println("PropertyUtil loadProperties Start : " + sdf.format(date));

        try {
            properties.load(Files.newBufferedReader(Paths.get(propFile), StandardCharsets.UTF_8));
        } catch (IOException e) {
            // ファイル読み込みに失敗
//            System.out.println(String.format("ファイルの読み込みに失敗しました。ファイル名:%s", propFile));
            LOGGER_STACKTRACE(ERROR, String.format("ファイルの読み込みに失敗しました。ファイル名:%s", propFile), e);
        }
//        GET_MESSAGE("N0000009", propFile);
//        LOGGER(DEBUG, msgUtil.GET_MESSAGE("N0000009",propFile));
//        System.out.println("PropertyUtil loadProperties End   : " + sdf.format(new Date()));
        
        LOGGER_TRACE_END();
    }

    /**
     * プロパティ値を取得する
     *
     * @param key キー
     * @return 値
     */
//    public static String GET_PROPERTY(final String key) {
    public static String getProperty(final String key) {
        return getProperty(key, "");
    }

    /**
     * プロパティ値を取得する
     *
     * @param key キー
     * @param defaultValue デフォルト値
     * @return キーが存在しない場合、デフォルト値
     *          存在する場合、値
     */
//    public static String GET_PROPERTY(final String key, final String defaultValue) {
    public static String getProperty(final String key, final String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }
    
    
//    /**
//     * プロパティファイルを更新
//     *
//     * @param filepath プロパティファイル
//     * @param map プロパティ設定値
//     * @return 
//     * @throws IOException 
//     */
//    public static void outputProperty(String propfile, Map<String, String> map) throws IOException {
//
//    	LOGGER_TRACE_START();
//
//    	try {
//        	
//        	Path path = Paths.get(propfile);
//            List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
//          
//            String propKey = "";
//            String propValue = "";
//            String mapValue = "";
//            int propDivIndex = 0;
//    		System.out.println("map :" + map );
//    		
//    		int i = 0;
//            for( String line : lines) {
//                propKey = "";
//                propValue = "";
//                mapValue = "";
//
//                propDivIndex = line.indexOf("=");
//            	if(propDivIndex != -1) {
//            		propKey = line.substring(0, propDivIndex);
//            		propValue = line.substring(propDivIndex +1);
//
//            		System.out.println("propKey = " + propKey );
//            		System.out.println("propValue = " + propValue );
//            		
//            		
//            		mapValue = map.get(propKey);
//            		System.out.println("mapValue :" + mapValue );
//            		System.out.println("line before:" + line );
//            		if( mapValue != null ){
//            			lines.set(i, propKey + "=" + mapValue);
//            		}
//            		System.out.println("line after [" +i +"]:" + line );
//            	}
//        		i++;
//            }
//    		System.out.println("lines :" + lines );
//            
//            // 新規で書き込みたいとき
//            Files.write(path, lines, StandardCharsets.UTF_8, StandardOpenOption.WRITE);
//            
//            reload();
//            
//        } catch (IOException e) {
//            e.printStackTrace();
//            throw e;
//        }
//
//    	LOGGER_TRACE_END();
//    }
}