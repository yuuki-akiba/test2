package com.example.demo.common;

import static com.example.demo.common.SipLogger.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.IllegalFormatException;
import java.util.Locale;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

@Service
public class MessageUtil {
    
//    public static final String MASSAGE_DEF_FILE_PATH = "resource/message.properties";
//    public static final String MSG_ID_NOT_DEFINE = "S000001";
//    private static final Properties properties;
	
	private final MessageSource messageSource;
	
//	@Autowired
	public MessageUtil(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	
//    private MessageUtil() throws Exception {
//    }

//    static {
//    	LOGGER_TRACE_START();
//    	LOGGER(DEBUG, "MessageUtil static");
//        properties = new Properties();
//        loadProperties();
//        LOGGER_TRACE_END();
//    }
//
//    /**
//     * 再読み込み
//     *
//     * @param key キー
//     * @return 値
//     */
//    public static void reload() {
//    	LOGGER_TRACE_START();
//        loadProperties();
//        LOGGER_TRACE_END();
//    }
//
//    /**
//     * プロパティファイル読み込み
//     *
//     * @param 
//     * @return 
//     */
//    private static void loadProperties() {
//        
//    	LOGGER_TRACE_START();
//
//        try {
//            properties.load(Files.newBufferedReader(Paths.get(MASSAGE_DEF_FILE_PATH), StandardCharsets.UTF_8));
//        } catch (IOException e) {
//            // ファイル読み込みに失敗
//            System.out.println(String.format("ファイルの読み込みに失敗しました。ファイル名:%s", MASSAGE_DEF_FILE_PATH));
//        }
//        
//        LOGGER_TRACE_END();
//    }

    /**
     * メッセージを取得する
     *
     * @param key キー
     * @param params 埋め込みパラメータ
     * @return 値
     */
    public String GET_MESSAGE(final String id, Object ... params) {

    	LOGGER_TRACE_START();
    	String message = "";
    	
//        String msgFormat = properties.getProperty(id);
//    	String[] msgParam = params;

//        if(msgFormat == null || msgFormat == "") {
//        	// メッセージプロパティ未定義
//        	msgFormat = properties.getProperty(MSG_ID_NOT_DEFINE);
//        	msgParam = new String[] { id };
//        }

        try {
//        	message = String.format(msgFormat, (Object[])msgParam);
        	
        	message = messageSource.getMessage(id, params, "メッセージ未設定[id=" + id + "]", Locale.JAPAN);
        	
        }catch(IllegalFormatException ife) {
        	LOGGER_STACKTRACE(ERROR, "メッセージ取得エラー", ife);
        	message = "";
        }
    	
        LOGGER_TRACE_END();
    	return message;
    }

    
    /**
     * メッセージを取得する
     *
     * @param key キー
     * @param params 埋め込みパラメータ
     * @return 値
//     */
//    public static String GET_MESSAGExxx(final String id, Object ... params) {
//
//    	LOGGER_TRACE_START();
//    	String message = "";
//    	
//        String msgFormat = properties.getProperty(id);
//    	String[] msgParam = new String[params.length];
//    	
//    	for(Object param : params) {
//    		
//    		
//    		
//    		if(param.getClass().getSimpleName().equals("int")){
//    			
//    		}
//    		
//    	}
//    	
//    	
//    	
//
//        if(msgFormat == null || msgFormat == "") {
//        	// メッセージプロパティ未定義
//        	msgFormat = properties.getProperty(MSG_ID_NOT_DEFINE);
//        	msgParam = new String[] { id };
//        }
//
//        try {
////        	message = String.format(msgFormat, (Object[])msgParam);
//        	
//        	message = messageSource.getMessage(id, msgParam, "メッセージ未設定", Locale.JAPAN);
//        	
//        }catch(IllegalFormatException ife) {
//        	LOGGER(ERROR, "メッセージ取得エラー");
//        	message = "";
//        }
//    	
//        LOGGER_TRACE_END();
//    	return message;
//    }
}