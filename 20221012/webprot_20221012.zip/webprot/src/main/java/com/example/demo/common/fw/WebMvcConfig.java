package com.example.demo.common.fw;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
  @Bean
  AuthInterceptor myInterceptor() {
    return new AuthInterceptor();
  }

  @Override
  public void addInterceptors(InterceptorRegistry registry) {
//    registry.addInterceptor(myInterceptor()).excludePathPatterns("/menu");
//	  List<String> pathList = new ArrayList<String>();
//	  pathList.add("/menu");
//	  pathList.add("/uriup");
//	  pathList.add("/uridown");
//	  pathList.add("/dbdown");
//    registry.addInterceptor(myInterceptor()).addPathPatterns(pathList);
    registry.addInterceptor(myInterceptor());
  }
  
  @Bean
  public MessageSource messageSource() {

      ReloadableResourceBundleMessageSource bean = new ReloadableResourceBundleMessageSource();
      //メッセージのプロパティファイル名（デフォルト）を指定します
      //下記ではmessages.propertiesファイルがセットされます
      bean.setBasename("classpath:messages");
      //メッセージプロパティの文字コードを指定します
      bean.setDefaultEncoding("UTF-8");
      return bean;
  }

  @Bean
  public LocalValidatorFactoryBean localValidatorFactoryBean() {
      LocalValidatorFactoryBean localValidatorFactoryBean = new LocalValidatorFactoryBean();
      localValidatorFactoryBean.setValidationMessageSource(messageSource());
      return localValidatorFactoryBean;
  }
}