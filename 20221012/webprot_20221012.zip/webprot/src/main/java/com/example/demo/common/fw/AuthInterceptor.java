package com.example.demo.common.fw;

import static com.example.demo.common.SipLogger.*;

import java.io.IOException;

import javax.naming.AuthenticationException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.thymeleaf.util.StringUtils;

import com.example.demo.model.AuthData;
import com.example.demo.model.InfomationData;

public class AuthInterceptor implements HandlerInterceptor {
	//	  private final AuthData authData = new AuthData();
	@Autowired
	private AuthData authData;
	@Autowired
	private InfomationData infoData;

	/** {@inheritDoc} 
	 * @throws IOException */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws AuthenticationException, IOException {
		LOGGER_TRACE_START();

		infoData.clear();
		LOGGER(WARN, "preHandle********************************************************** :[" +  ((HttpServletRequest) request).getRequestURI() + "]");

//		int t = request.getSession().getMaxInactiveInterval();
//		System.out.println(t);
//		t = request.getSession().getMaxInactiveInterval();
//		System.out.println(t);

		// セッションユーザ情報チェック
//		if (isLoginCheckUrl(request) && isTarget(request)) {
		if (isLoginCheckUrl(request) ) {
			// セッションタイムアウトのチェック
			if (isSessionTimeout(request)) { // セッションタイムアウトの場合
				LOGGER(WARN, "セッションタイムアウト");
				// Ajax処理の場合は「セッションタイムアウトが発生しました。ログインしなおしてください。」というメッセージを返却する。
				if (isAjaxRequest(request)) {
					String message = "{\"success\":false,\"messages\":[\"セッションタイムアウトが発生しました。ログインしなおしてください。\"]}";
					response.setContentType("text/html;charset=UTF-8");
					// ステータスは200となるが、success = falseとする。
					response.setStatus(HttpServletResponse.SC_OK);
					response.getWriter().write(message);
					return false;
				} else {
					// 通常画面の場合は、ログイン画面を表示しセッションタイムアウトメッセージを伝える。
					infoData.setData("1", "セッションタイムアウトが発生しました。ログインしなおしてください。");
					response.sendRedirect("/login/timeout");
					return false;
				}
			} else {
				if (null == authData.getUserId() || "".equals(authData.getUserId()) ||
						null == authData.getPassword() || "".equals(authData.getPassword())) {
					//		      throw new AuthenticationException("ログインしてください。");
					LOGGER(WARN, "ログイン情報未設定");
					response.sendRedirect("/login/noauth");
					return false;
				} else {
					LOGGER(INFO, "ログイン中");
				}
			}
		}

		LOGGER_TRACE_END();
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		LOGGER_TRACE_START();
		LOGGER(INFO, "do nothing");
		LOGGER_TRACE_END();
	}


	/**
	 * 対象のリクエストか判定
	 * ログイン、環境設定画面についてはチェック対象外
	 * css, js, favicon等のリソースアクセスについてはチェック対象外
	 *
	 * @param request リクエスト
	 * @return true : チェック対象 / false : チェック対象ではない
	 */
	private boolean isLoginCheckUrl(HttpServletRequest request) {

		var listLogincheck = new String[][] {
			{ "/login", "1" },
			{ "/error", "1" },
			{ "/css/", "1" },
			{ "/js/", "1" },
			{ "/favicon.ico", "1" },
			{ "/comprop", "0" }
		};

		String uri = ((HttpServletRequest) request).getRequestURI();
		for (String[] check : listLogincheck) {

			if (check.length == 2) {
				if (check[1].equals("0") && check[0].equals(uri)) {
					LOGGER(INFO, "isLoginCheckUrl false match except  uri :[" + uri + "]");
					return false;
				} else if (check[1].equals("1") && uri.indexOf(check[0]) >= 0) {
					LOGGER(INFO, "isLoginCheckUrl false contain except  uri :[" + uri + "]");
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * 対象のリクエストか判定
	 * css, js, favicon等のリソースアクセスについては出力対象外
	 *
	 * @param request リクエスト
	 * @return true : ロギング対象 / false : ロギング対象ではない
	 */
//	private boolean isTarget(ServletRequest request) {
//		String uri = ((HttpServletRequest) request).getRequestURI();
//		return (uri.indexOf("/css/") < 0 && uri.indexOf("/js/") < 0 && uri.indexOf("/favicon.ico") < 0);
//	}

	/**
	 * Ajaxリクエスト判定
	 *
	 * @param request リクエスト
	 * @return true : Ajaxリクエスト / false : そうではない
	 */
	private boolean isAjaxRequest(ServletRequest request) {
		return StringUtils.equals("XMLHttpRequest",
				((HttpServletRequest) request).getHeader("X-Requested-With"));
	}

	/**
	 * セッションタイムアウト判定
	 *
	 * @param request
	 * @return
	 */
	private boolean isSessionTimeout(HttpServletRequest request) {
		HttpSession falsecurrentSession = request.getSession(false);
		LOGGER(INFO, "request :" + request);
		LOGGER(INFO, "falsecurrentSession :" + falsecurrentSession);
		if (falsecurrentSession == null) {
			return true;
		}
		String requestSession = request.getRequestedSessionId();
		LOGGER(INFO, "requestSession :" + requestSession);
		boolean isValid = request.isRequestedSessionIdValid();
		LOGGER(INFO, "isValid :" + isValid);
		LOGGER(INFO, "falsecurrentSession.getId() :" + falsecurrentSession.getId());

		return falsecurrentSession == null || requestSession == null || !isValid
				|| !requestSession.equals(falsecurrentSession.getId());
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
			Object handler, Exception ex) throws Exception {
	}
}
