package com.example.demo.model;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import lombok.Data;

@Data
@Component
@SessionScope
public class InfomationData {

    public  final String MSG_TYPE_NORMAL = "0";
    public  final String MSG_TYPE_WARN = "1";
    public  final String MSG_TYPE_ERROR = "9";

	// メッセージ種別
	private String type;
	// メッセージ
	private String message;
	
	public void setData(String type, String message) {
		this.type = type;
		this.message = message;
	}

	public void clear() {
		this.type = "";
		this.message = "";
	}
}