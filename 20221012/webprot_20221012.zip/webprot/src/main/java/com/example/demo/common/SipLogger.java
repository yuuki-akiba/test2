package com.example.demo.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SipLogger {

	public final static int TRACE = 1;
	public final static int DEBUG = 2;
	public final static int INFO = 3;
	public final static int WARN = 4;
	public final static int ERROR = 5;
	private static final Logger logger;

	static {
//		logger = LoggerFactory.getLogger(SipLogger.class.getClass());
		logger = LoggerFactory.getLogger("siplogger");
		
	}

	/**
	 * ログ出力
	 *
	 * @param level ログ出力レベル
	 * @param msg 出力メッセージ
	 * @return 値
	 */
	public static void LOGGER(int level, String msg) {
		switch (level) {
			case TRACE:
				logger.trace(msg);
				break;
			case DEBUG:
				logger.debug(msg);
				break;
			case INFO:
				logger.info(msg);
				break;
			case WARN:
				logger.warn(msg);
				break;
			case ERROR:
				logger.error(msg);
				break;
			default:
				logger.info(msg);
		}
	}

	/**
	 * スタックトレースログ出力
	 *
	 * @param level ログ出力レベル
	 * @param msg 出力メッセージ
	 * @param e Exception
	 * @return 値
	 */
	public static void LOGGER_STACKTRACE(int level, String msg, Exception e) {
		switch (level) {
			case TRACE:
				logger.trace(msg, e);
				break;
			case DEBUG:
				logger.debug(msg, e);
				break;
			case INFO:
				logger.info(msg, e);
				break;
			case WARN:
				logger.warn(msg, e);
				break;
			case ERROR:
				logger.error(msg, e);
				break;
			default:
				logger.error(msg, e);
		}
	}

	/**
	 * ログ出力 トレース 開始
	 *
	 * @param level ログ出力レベル
	 * @param msg 出力メッセージ
	 * @return 値
	 */
	public static void LOGGER_TRACE_START() {
	
//		String msg;
//		msg = Thread.currentThread().getStackTrace()[2].getClassName() + "." +
//				Thread.currentThread().getStackTrace()[2].getMethodName() + " -- Start";
//		SipLogger.LOGGER(TRACE, msg);
//
//		String msg;
//		String classNameFull = Thread.currentThread().getStackTrace()[2].getClassName();
//		String className = classNameFull.substring(classNameFull.lastIndexOf("."));
//		String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
//		msg = className + "." + methodName + " -- Start";
//		msg = calledFromMethoName() +  " -- Start";
//		SipLogger.LOGGER(TRACE, msg);
		SipLogger.LOGGER(TRACE, calledFromMethoName() +  " -- Start");
	}

	/**
	 * ログ出力 トレース 終了
	 *
	 * @param level ログ出力レベル
	 * @param msg 出力メッセージ
	 * @return 値
	 */
	public static void LOGGER_TRACE_END() {
	
//		String msg;
//		String classNameFull = Thread.currentThread().getStackTrace()[2].getClassName();
//		String className = classNameFull.substring(classNameFull.lastIndexOf("."));
//		String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
//		msg = Thread.currentThread().getStackTrace()[2].getClassName() + "." +
//				Thread.currentThread().getStackTrace()[2].getMethodName() + " -- End";
//		msg = className + "." + methodName + " -- End";
//		String msg = calledFromMethoName() +  " -- End";
//		SipLogger.LOGGER(TRACE, msg);
		SipLogger.LOGGER(TRACE, calledFromMethoName() +  " -- End");
	}
	
	/**
	 * 呼出し元のクラス名＋メソッド名
	 *
	 * @param level ログ出力レベル
	 * @param msg 出力メッセージ
	 * @return 値
	 */
	private static String calledFromMethoName() {
		String classNameFull = Thread.currentThread().getStackTrace()[3].getClassName();
		String className = classNameFull.substring(classNameFull.lastIndexOf(".") +1);
		String methodName = Thread.currentThread().getStackTrace()[3].getMethodName();
		return className + "." + methodName;
	}
}
