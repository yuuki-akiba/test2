/**
 * 
 */
package com.example.demo.api;

import static com.example.demo.common.CommonPropertyUtil.*;
////import static com.example.demo.common.PropertyUtil.*;
import static com.example.demo.common.SipLogger.*;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ProxySelector;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;

public class HttpRequestCall {
	
	public final int STSCD_AUTH_SUCCESS = 302;
	public final int STSCD_AUTH_FAILED  = 401;

	private final HttpClient httpClient;

    public HttpRequestCall() {
		LOGGER_TRACE_START();
		
//		LOAD_PROP();

        if( null != GET_PROPERTY(PROP_KEY_PROXY_HOST) &&
        	!"".equals(GET_PROPERTY(PROP_KEY_PROXY_HOST))){
            LOGGER(DEBUG, "proxyサーバー :" + GET_PROPERTY(PROP_KEY_PROXY_HOST) + ":" + GET_PROPERTY(PROP_KEY_PROXY_PORT));
        	int proxy_port_int = 0;
        	try {
        		proxy_port_int = Integer.parseInt(GET_PROPERTY(PROP_KEY_PROXY_PORT));
        	}catch(Exception e) {
//                LOGGER(ERROR, "proxyサーバー port設定エラー [" + GET_PROPERTY(PROP_KEY_PROXY_PORT) + "]");
//    			e.printStackTrace();
                LOGGER_STACKTRACE(ERROR, "proxyサーバー port設定エラー [" + GET_PROPERTY(PROP_KEY_PROXY_PORT) + "]", e);
        		throw e;
        	}
        	
            this.httpClient = HttpClient.newBuilder()
                    .proxy(ProxySelector.of(new InetSocketAddress(GET_PROPERTY(PROP_KEY_PROXY_HOST), proxy_port_int)))
                    .build();
        }else {
//            System.out.println("proxyサーバーホスト :未設定");
            LOGGER(INFO, "proxyサーバーホスト :未設定");
        	this.httpClient = HttpClient.newBuilder()
                    .build();
        }
        
		LOGGER_TRACE_END();
    }
        

    public HttpRequestCall(HttpClient httpClient) {
        this.httpClient = httpClient;
    }

    /**
     * 認証トークン取得(Post)
     */
    public  HttpResponse<String> postAuth(Map<String, ?> param) throws IOException, InterruptedException {
    	
		LOGGER_TRACE_START();

    	StringBuilder uriStr = new StringBuilder();

    	// URIホスト／パス
    	uriStr.append(GET_PROPERTY(PROP_KEY_API_URI_HOST)).append(GET_PROPERTY(PROP_KEY_AUTH_API_URI_PATH));
    	// URIパラーメータ テナントＩＤ
    	uriStr.append("?tenantId=").append(GET_PROPERTY(PROP_KEY_AUTH_API_PARAM_TENANT_ID));
    	// URIパラーメータ ユーザＩＤ
    	uriStr.append("&userId=").append(param.get("userId"));
    	// URIパラーメータ パスワード
    	uriStr.append("&password=").append(param.get("password"));
    	// URIパラーメータ クライアントＩＤ
    	uriStr.append("&client_id=").append(GET_PROPERTY(PROP_KEY_AUTH_API_PARAM_CLIENT_ID));
    	// URIパラーメータ レスポンスタイプ
    	uriStr.append("&response_type=").append(GET_PROPERTY(PROP_KEY_AUTH_API_PARAM_RESPONSE_TYPE));
    	// URIパラーメータ リダイレクトＵＲＩ
    	uriStr.append("&redirect_uri=").append(GET_PROPERTY(PROP_KEY_AUTH_API_PARAM_REDIRECT_URI));

        LOGGER(DEBUG, "uriStr :" + uriStr);
    	HttpRequest httpRequest = HttpRequest.newBuilder(URI.create(uriStr.toString()))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(""))
                .build();

        // API Call
    	HttpResponse<String> httpResponse = this.httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        LOGGER(DEBUG, "httpResponse.statusCode() : " + httpResponse.statusCode());
        LOGGER(DEBUG, "httpResponse.body() :" + httpResponse.body());

        LOGGER_TRACE_END();

        return httpResponse;
        
    }

    /**
     * URIアップロード(Post)
     */
    public HttpResponse<String> postUriUpload(String token, String jsonStr) throws IOException, InterruptedException {
    	
		LOGGER_TRACE_START();

    	String strAuthParam = "Bearer " + token;

    	StringBuilder uriStr = new StringBuilder();
    	uriStr.append(GET_PROPERTY(PROP_KEY_API_URI_HOST)).append(GET_PROPERTY(PROP_KEY_COM_API_URI_PATH_URIUPLOAD)) ; 

    	HttpRequest httpRequest = HttpRequest.newBuilder(URI.create(uriStr.toString()))
                .header("Content-Type", "application/json")
                .header("Authorization", strAuthParam)
                .POST(HttpRequest.BodyPublishers.ofString(jsonStr))
                .build();

        HttpResponse<String> httpResponse = this.httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        LOGGER(DEBUG, "httpResponse.statusCode() : " + httpResponse.statusCode());
        LOGGER(DEBUG, "httpResponse.body() :" + httpResponse.body());
        
        LOGGER_TRACE_END();

        return httpResponse;
    }

    /**
     * URIダウンロード(Post)
     */
    public HttpResponse<String> postUriDownload(String token, String jsonStr) throws IOException, InterruptedException {
    	
		LOGGER_TRACE_START();

    	String strAuthParam = "Bearer " + token;

    	StringBuilder uriStr = new StringBuilder();
    	uriStr.append(GET_PROPERTY(PROP_KEY_API_URI_HOST)).append(GET_PROPERTY(PROP_KEY_COM_API_URI_PATH_URIDOWNLOAD)) ; 

    	HttpRequest httpRequest = HttpRequest.newBuilder(URI.create(uriStr.toString()))
                .header("Content-Type", "application/json")
                .header("Authorization", strAuthParam)
                .POST(HttpRequest.BodyPublishers.ofString(jsonStr))
                .build();

        HttpResponse<String> httpResponse = this.httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        LOGGER(DEBUG, "httpResponse.statusCode() : " + httpResponse.statusCode());
        LOGGER(DEBUG, "httpResponse.body() :" + httpResponse.body());

        LOGGER_TRACE_END();

        return httpResponse;
    }

    /**
     * 個社DBダウンロード(Post)
     */
    public HttpResponse<String> postDbDownload(String token, String jsonStr) throws IOException, InterruptedException {
        
		LOGGER_TRACE_START();

        String strAuthParam = "Bearer " + token;

//        System.out.println("Request JSON : " + jsonStr);
        LOGGER(DEBUG, "Request JSON : " + jsonStr);

        StringBuilder uriStr = new StringBuilder();
        uriStr.append(GET_PROPERTY(PROP_KEY_API_URI_HOST)).append(GET_PROPERTY(PROP_KEY_COM_API_URI_PATH_DBDOWNLOAD)) ; 

        HttpRequest httpRequest = HttpRequest.newBuilder(URI.create(uriStr.toString()))
                .header("Content-Type", "application/json")
                .header("Authorization", strAuthParam)
                .POST(HttpRequest.BodyPublishers.ofString(jsonStr))
                .build();

        HttpResponse<String> httpResponse = this.httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        LOGGER(DEBUG, "httpResponse.statusCode() : " + httpResponse.statusCode());
        LOGGER(DEBUG, "httpResponse.body() :" + httpResponse.body());

        LOGGER_TRACE_END();

        return httpResponse;
    }

}