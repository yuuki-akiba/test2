package com.example.demo.action;

import static com.example.demo.common.SipLogger.*;

import java.io.IOException;
import java.io.OutputStream;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.JsonConverter;
import com.example.demo.api.HttpRequestCall;
import com.example.demo.common.MessageUtil;
import com.example.demo.model.AuthData;
import com.example.demo.model.DbDownloadData;
import com.example.demo.model.DbDownloadForm;
import com.example.demo.model.DbDownloadListForm;
import com.example.demo.model.InfomationData;
import com.example.demo.model.SearchItem;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
//@ComponentScan("com.example.demo")
public class DbDownloadAction {

	private final InfomationData infoData;
	private final MessageUtil msgUtil;
	private final AuthData authData;

	//	@Autowired
	public DbDownloadAction(InfomationData infoData, MessageUtil msgUtil, AuthData authData) {
		this.infoData = infoData;
		this.authData = authData;
		this.msgUtil = msgUtil;
	}

	public String initiaized(Model model) {

		LOGGER_TRACE_START();

		DbDownloadForm form = new DbDownloadForm();

		List<SearchItem> searchItems = new ArrayList<SearchItem>();
		form.setGetStatus("2");
		form.setEachDataFlag("true");

		searchItems.add(new SearchItem());
		searchItems.add(new SearchItem());
		searchItems.add(new SearchItem());
		form.setSearchItems(searchItems);
		//		form.setApiResult("");

		model.addAttribute("form", form);
		model.addAttribute("infoData", infoData);

		LOGGER_TRACE_END();

		return "dbdown";
	}

	public String execute(DbDownloadForm form, Model model, HttpServletResponse response) {

		LOGGER_TRACE_START();

		HttpResponse<String> res = null;

		model.addAttribute("form", form);
		model.addAttribute("infoData", infoData);

//		JsonConverter jsonConv = new JsonConverter();
//		String jsonStr = jsonConv.getDbDownloadJsonStr(form);
		HttpRequestCall api = new HttpRequestCall();

		try {
			Map<String, String> param = new HashMap<>();
			// セッション情報の認証情報をセット
			param.put("userId", authData.getUserId());
			param.put("password", authData.getPassword());

			// アクセストークン取得
			String token = "";
			res = api.postAuth(param);

			// 認証OK
			if (res.statusCode() == api.STSCD_AUTH_SUCCESS) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode jsonResult = mapper.readTree(res.body());
//				System.out.println("access_token : " + jsonResult.get("access_token").asText());
				LOGGER(INFO, "access_token : " + jsonResult.get("access_token").asText());

				// 認証トークン
				token = jsonResult.get("access_token").asText();

				// リクエストパラメータ編集
				JsonConverter jsonConv = new JsonConverter();
				String jsonStr = jsonConv.getDbDownloadJsonStr(form);

				// 個社DBダウンロードAPI呼出し
				res = api.postDbDownload(token, jsonStr);
//				if (res.statusCode() == 200 || res.statusCode() == 201) {
				if (res.statusCode() == 201) {
					
					LOGGER(INFO, msgUtil.GET_MESSAGE("N006001"));
					infoData.setData(infoData.getMSG_TYPE_NORMAL(), msgUtil.GET_MESSAGE("N006001"));

					Map<String, Object> map = null;
					map = mapper.readValue(res.body(), new TypeReference<Map<String, Object>>() {
					});

					//debug
					//					Map<String, Object> map = new HashMap<String, Object>();
					//					String str1 = "\"1\",\"1\",\"1\",\"\",\"1\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"\",\"\",\"118010024\",\"1\",\"1\",\"1\",\"\",\"ジンマー\",\"1\",\"\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"1\",\"1\",\"\",\"1\",\"\",\"H3863\",\"1\",\"\",\"1\",\"\",\"\",\"sip-md-ad01\",\"\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"\",\"1\",\"\",\"1\",\"2\",\"3\",\"4\",\"\",\"5\",\"6\",\"\",\"7\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"1\",\"\",\"1\",\"\",\"1\",\"\",\"\",\"z\",\"\"\r\n\"1\",\"1\",\"1\",\"\",\"1\",\"1\",\"1\",\"\",\"11\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"\",\"\",\"2610308609\",\"1\",\"11\",\"1\",\"\",\"ジンマー\",\"1\",\"\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"1\",\"11\",\"\",\"1\",\"\",\"H7402\",\"1\",\"\",\"1\",\"\",\"\",\"sip-md-u08\",\"\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"\",\"1\",\"\",\"u8a\",\"u8b\",\"u8c\",\"u8d\",\"\",\"u8e\",\"u8f\",\"\",\"u8g\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"1\",\"\",\"1\",\"\",\"1\",\"\",\"\",\"zz\",\"\"\r\n\"1\",\"1\",\"1\",\"\",\"1\",\"1\",\"　　\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"1\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"1\",\"1\",\"\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"\",\"\",\"sip-md-ad01\",\"\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"\",\"1\",\"\",\"1\",\"2\",\"3\",\"4\",\"\",\"5\",\"6\",\"\",\"7\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"1\",\"\",\"1\",\"\",\"1\",\"\",\"\",\"zzz\",\"\"\r\n\"1\",\"1\",\"1\",\"\",\"1\",\"1\",\"1\",\"\",\"11\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"1\",\"11\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"1\",\"11\",\"\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"\",\"\",\"sip-md-u08\",\"\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"\",\"1\",\"\",\"u8a\",\"u8b\",\"u8c\",\"u8d\",\"\",\"u8e\",\"u8f\",\"\",\"u8g\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"1\",\"1\",\"\",\"\",\"\",\"\",\"1\",\"\",\"1\",\"\",\"1\",\"\",\"\",\"zzzz\",\"\"\n";
					//					map.put("download_data", str1);

					if (map.get("download_data") != null) {

						// CSVダウンロード
						if (form.getSubmitType().equals("csv")) {
							try (OutputStream os = response.getOutputStream();) {

//								System.out.println("response.getOutputStream :" + res.body());
								LOGGER(DEBUG, "response.getOutputStream :" + res.body());

								byte[] fb1 = ((String) map.get("download_data")).getBytes("UTF-8");

								Date date = new Date();
								SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
								String outFileName = "db_download_" + sdf.format(date) + ".txt";

								response.setContentType("application/octet-stream");
								response.setHeader("Content-Disposition", "attachment; filename=" + outFileName);
								response.setHeader("Set-Cookie", "fileDownload=true; path=/");
								response.setContentLength(fb1.length);
								os.write(fb1);
								os.flush();

								LOGGER_TRACE_END();
								return null;
							} catch (IOException e) {
								LOGGER_STACKTRACE(ERROR, "response.getOutputStream エラー", e);
							}
							// 一覧表示画面
						} else {
							String data = (String) map.get("download_data");

							DbDownloadListForm listForm = new DbDownloadListForm();
							listForm.setDownloadDatas(editDbDownloadDataList(data));
							model.addAttribute("form", listForm);
							LOGGER_TRACE_END();
							return "dbdownlist";
						}

					} else {
//						LOGGER(INFO, "個社DBダウンロードレスポンスデータエラー");
						LOGGER(WARN, msgUtil.GET_MESSAGE("E001002", "個社DBダウンロード", res.statusCode(), res.body()));
						infoData.setData(infoData.MSG_TYPE_ERROR, msgUtil.GET_MESSAGE("E001002", "個社DBダウンロード", res.statusCode(), res.body()));
					}
				} else {
//					LOGGER(INFO, "個社DBダウンロードステータスコードエラー");
					LOGGER(WARN, msgUtil.GET_MESSAGE("E001001", "個社DBダウンロード", res.statusCode(), res.body()));
					infoData.setData(infoData.MSG_TYPE_ERROR, msgUtil.GET_MESSAGE("E001001", "個社DBダウンロード", res.statusCode(), res.body()));
				}
			} else {
				// 認証エラー
				if (res.statusCode() == api.STSCD_AUTH_FAILED) {
					LOGGER(WARN, msgUtil.GET_MESSAGE("W001003"));
					infoData.setData(infoData.MSG_TYPE_WARN, msgUtil.GET_MESSAGE("W001003"));
				// 認証APIステータスコードエラー
				} else {
					LOGGER(WARN, msgUtil.GET_MESSAGE("E001001", "認証", res.statusCode(), res.body()));
					infoData.setData(infoData.MSG_TYPE_ERROR,
							msgUtil.GET_MESSAGE("E001001", "認証", res.statusCode(), res.body()));
				}
			}
		} catch (IOException | InterruptedException e) {
			// TODO 自動生成された catch ブロック
			//			e.printStackTrace();
			LOGGER_STACKTRACE(ERROR, "例外発生", e);
		}
		LOGGER_TRACE_END();

		return "dbdown";

	}

	private List<DbDownloadData> editDbDownloadDataList(String strData) {
		List<DbDownloadData> list = new ArrayList<DbDownloadData>();

		String array1[] = strData.replace("\",\"", ",").split("\r\n|\n");

		String item[] = new String[111];

		for (String record : array1) {

			record = trimDoubleQuot(record);
			String itemTmp[] = record.split(",", -1);
			
			for(int i = 0; i < item.length; i ++) {
				if(i < itemTmp.length) {
					item[i] = itemTmp[i];
				}else {
					item[i] = "";
				}
			}

			DbDownloadData data = new DbDownloadData();

			data.setMsg_id(item[0]);
			data.setMsg_info_cls_typ_cd(item[1]);
			data.setMsg_date_iss_dttm(item[2]);
			data.setMsg_time_iss_dttm(item[3]);
			data.setMsg_fn_stas_cd(item[4]);
			data.setNote_dcpt_txt(item[5]);
			data.setEsti_inlet_id(item[6]);
			data.setEsti_inlet_cls_typ_cd(item[7]);
			data.setRped_inlet_id(item[8]);
			data.setInlet_date_subm_dttm(item[9]);
			data.setInlet_time_subm_dttm(item[10]);
			data.setTrsp_instruction_id(item[11]);
			data.setInv_num_id(item[12]);
			data.setTrsp_means_typ_cd(item[13]);
			data.setCar_cls_dcpt_txt(item[14]);
			data.setEsti_depa_from_date(item[15]);
			data.setEsti_depa_to_date(item[16]);
			data.setDepa_date_prfm_dttm(item[17]);
			data.setDel_slip_num_id(item[18]);
			data.setDel_slip_secondary_num_id(item[19]);
			data.setRped_totl_pcks_quan(item[20]);
			data.setNum_unt_cd(item[21]);
			data.setRped_totl_weig_meas(item[22]);
			data.setWeig_unt_cd(item[23]);
			data.setRped_totl_vol_meas(item[24]);
			data.setVol_unt_cd(item[25]);
			data.setLine_item_num_id(item[26]);
			data.setInlet_num_id(item[27]);
			data.setSev_ord_num_id(item[28]);
			data.setRped_lot_num_id(item[29]);
			data.setCls_of_sell_item_cd(item[30]);
			data.setItem_cls_txt(item[31]);
			data.setGtin_item_cd(item[32]);
			data.setShpm_item_idr_cls_cd(item[33]);
			data.setShpm_item_sev_idr_cd(item[34]);
			data.setBuy_assi_item_cd(item[35]);
			data.setSell_assi_item_cd(item[36]);
			data.setWrhs_assi_item_cd(item[37]);
			data.setItem_name_txt(item[38]);
			data.setShrt_item_name_txt(item[39]);
			data.setStnd_txt(item[40]);
			data.setCls_of_qual_cd(item[41]);
			data.setCls_of_item_qual_cd(item[42]);
			data.setCls_of_kpng_tmp_cd(item[43]);
			data.setNum_of_rped_quan(item[44]);
			data.setSev_num_unt_cd(item[45]);
			data.setItem_weig_meas(item[46]);
			data.setSev_weig_unt_cd(item[47]);
			data.setCnte_meas_per_pcke_meas(item[48]);
			data.setRped_quan_meas(item[49]);
			data.setCnte_num_unt_cd(item[50]);
			data.setCnte_num_per_pcke_quan(item[51]);
			data.setRped_bulk_num_quan(item[52]);
			data.setRped_bulk_num_unt_cd(item[53]);
			data.setPcke_frm_cd(item[54]);
			data.setPcke_frm_name_cd(item[55]);
			data.setGlb_retb_asse_id(item[56]);
			data.setRped_mnf_date_dttm(item[57]);
			data.setRped_vld_trm_dttm(item[58]);
			data.setDpsr_prty_head_off_id(item[59]);
			data.setDpsr_prty_brnc_off_id(item[60]);
			data.setDpsr_prty_name_txt(item[61]);
			data.setDpsr_sct_sped_org_id(item[62]);
			data.setDpsr_sct_sped_org_name_txt(item[63]);
			data.setCnee_prty_head_off_id(item[64]);
			data.setCnee_prty_brnc_off_id(item[65]);
			data.setCnee_prty_name_txt(item[66]);
			data.setCnee_sct_id(item[67]);
			data.setCnee_sct_name_txt(item[68]);
			data.setLogs_srvc_prv_prty_head_off_id(item[69]);
			data.setLogs_srvc_prv_prty_brnc_off_id(item[70]);
			data.setLogs_srvc_prv_prty_name_txt(item[71]);
			data.setLogs_srvc_prv_sct_sped_org_id(item[72]);
			data.setLogs_srvc_prv_sct_sped_org_name_txt(item[73]);
			data.setWrhs_prty_head_off_id(item[74]);
			data.setWrhs_prty_brnc_off_id(item[75]);
			data.setWrhs_prty_name_txt(item[76]);
			data.setWrhs_sct_sped_org_id(item[77]);
			data.setWrhs_sct_sped_org_name_txt(item[78]);
			data.setTrsp_cli_prty_head_off_id(item[79]);
			data.setTrsp_cli_prty_brnc_off_id(item[80]);
			data.setTrsp_cli_prty_name_txt(item[81]);
			data.setRoad_carr_depa_sped_org_id(item[82]);
			data.setRoad_carr_depa_sped_org_name_txt(item[83]);
			data.setWrhs_fee_clim_to_prty_head_off_id(item[84]);
			data.setWrhs_fee_clim_to_prty_brnc_off_id(item[85]);
			data.setWrhs_fee_clim_to_prty_name_txt(item[86]);
			data.setWrhs_fee_clim_to_sct_sped_org_id(item[87]);
			data.setWrhs_fee_clim_to_sct_sped_org_name_txt(item[88]);
			data.setShip_from_prty_head_off_id(item[89]);
			data.setShip_from_prty_brnc_off_id(item[90]);
			data.setShip_from_prty_name_txt(item[91]);
			data.setShip_from_sct_id(item[92]);
			data.setShip_from_sct_name_txt(item[93]);
			data.setShip_from_tel_cmm_cmp_num_txt(item[94]);
			data.setShip_from_plc_cd_prty_id(item[95]);
			data.setShip_from_gln_prty_id(item[96]);
			data.setShip_from_jpn_uplc_cd(item[97]);
			data.setShip_from_jpn_van_srvc_cd(item[98]);
			data.setShip_from_jpn_van_vans_cd(item[99]);
			data.setShip_to_prty_head_off_id(item[100]);
			data.setShip_to_prty_brnc_off_id(item[101]);
			data.setShip_to_prty_name_txt(item[102]);
			data.setShip_to_sct_id(item[103]);
			data.setShip_to_sct_name_txt(item[104]);
			data.setShip_to_plc_cd_prty_id(item[105]);
			data.setShip_to_gln_prty_id(item[106]);
			data.setShip_to_jpn_uplc_cd(item[107]);
			data.setShip_to_jpn_van_srvc_cd(item[108]);
			data.setShip_to_jpn_van_vans_cd(item[109]);
			data.setCtrl_flg(item[110]);
//			System.out.println(data);

			list.add(data);

			//		   for(String item : list) {
			//			  
			//			 System.out.println(item);
			//		   }
		}

		return list;

	}

	/**
	 * 文字列前後のダブルクォーテーションを削除するFunction
	 * @param str 文字列
	 * @return 前後のダブルクォーテーションを削除した文字列
	 */
	public static String trimDoubleQuot(String str) {
		char c = '"';
		if (str.charAt(0) == c && str.charAt(str.length() - 1) == c) {
			return str.substring(1, str.length() - 1);
		} else {
			return str;
		}
	}
}
