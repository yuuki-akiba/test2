package com.example.demo.action;

import static com.example.demo.common.ValidationPropertyUtil.*;
import static com.example.demo.common.SipLogger.*;

import java.io.IOException;
import java.io.OutputStream;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

import com.example.demo.JsonConverter;
import com.example.demo.api.HttpRequestCall;
import com.example.demo.common.MessageUtil;
import com.example.demo.model.AuthData;
import com.example.demo.model.CommonProperties;
import com.example.demo.model.DbDownloadData;
import com.example.demo.model.DbDownloadForm;
import com.example.demo.model.DbDownloadListForm;
import com.example.demo.model.InfomationData;
import com.example.demo.model.LoginForm;
import com.example.demo.model.UriDownloadForm;
import com.example.demo.model.UriUploadForm;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@ComponentScan("com.example.demo.model")
public class LoginAction {
	private final InfomationData infoData;
	private final MessageUtil msgUtil;
	private final AuthData authData;

//	@Autowired
//	private MessageUtil msgUtil;
//	@Autowired
//	public InfomationData infoData;
//	@Autowired
//	private AuthData authData;

//	@Autowired
	public LoginAction(InfomationData infoData, MessageUtil msgUtil, AuthData authData) {
		this.infoData = infoData;
		this.authData = authData;
		this.msgUtil = msgUtil;
	}

	public String initiaized(String option, Model model) {

		LOGGER_TRACE_START();

		LoginForm form = new LoginForm();
		infoData.clear();
		model.addAttribute("form", form);
		if (option != null) {
			if ("timeout".equals(option)) {
				infoData.setData(infoData.MSG_TYPE_WARN, msgUtil.GET_MESSAGE("W001001"));
			} else if ("noauth".equals(option)) {
				infoData.setData(infoData.MSG_TYPE_WARN, msgUtil.GET_MESSAGE("W001002"));
			}
			model.addAttribute("infoData", infoData);
		}

		LOGGER_TRACE_END();

		return "login";
	}

	//	public String execute(LoginForm form, Model model, HttpServletResponse response,
	//			AuthData authData) {
	public String execute(LoginForm form, BindingResult result, Model model) {

		LOGGER_TRACE_START();

		model.addAttribute("form", form);
		model.addAttribute("infoData", infoData);

		HttpResponse<String> res = null;
		HttpRequestCall api = new HttpRequestCall();

		infoData.clear();
		
		authData.setUserId("");
		authData.setPassword("");
		
        // バリデーションチェック結果
		if (result.hasErrors()) {
						
            List<String> errorList = new ArrayList<String>();
            for (FieldError error : result.getFieldErrors()) {
 
    		    // メッセージID
    		    String msgId = error.getDefaultMessage();
    			// 項目ID
    		    String fieldnm = GET_VLDPROP(error.getObjectName() + "." + error.getField());
    		    
    		    // メッセージ
    		    String msg = "";
    		    // 最大桁数
    		    int maxNum = 0;
    		    // 最小桁数
    		    int minNum = 0;
//    		    String[] param;
    		    if("Size".equals(error.getCode())){
    		    	// 最大桁数
    		    	maxNum = (int)error.getArguments()[1];
    		    	// 最小桁数
    		    	minNum = (int)error.getArguments()[2];
//    		    	param = new String[] {fieldnm, String.valueOf(maxNum), String.valueOf(minNum)};
    		    	
    		    	LOGGER(ERROR, "GET_MESSAGE(サイズ)");
    		    	LOGGER(ERROR, msgUtil.GET_MESSAGE(msgId, fieldnm, maxNum, minNum));
    		    	msg = msgUtil.GET_MESSAGE(msgId, fieldnm, maxNum, minNum);
    		    }else{
//    		    	param = new String[] {fieldnm};
    		    	LOGGER(ERROR, "GET_MESSAGE(バリデーション)");
    		    	LOGGER(ERROR, msgUtil.GET_MESSAGE(msgId, fieldnm));
    		    	msg = msgUtil.GET_MESSAGE(msgId, fieldnm);
    		    }
    		    
//            	String msg = messageSource.getMessage(msgId, param, "メッセージ未設定", Locale.JAPAN);
            	errorList.add(msg);
            }
            model.addAttribute("validationError", errorList);
            
            return "login";
        }
		
		// アクセストークン取得
		try {
			Map<String, String> param = new HashMap<>();

			param.put("userId", form.getUserId());
			param.put("password", form.getPassword());

			res = api.postAuth(param);

			if (res.statusCode() == api.STSCD_AUTH_SUCCESS) {
				LOGGER(INFO, "認証API成功");
				// セッション情報の認証情報セット
				authData.setUserId(form.getUserId());
				authData.setPassword(form.getPassword());
			} else {
				LOGGER(INFO, "認証API失敗");
				LOGGER(INFO, "[認証API実行エラー]" + "statusCode:" + res.statusCode() + "\nbody:" + res.body());
				// 認証エラー
				if (res.statusCode() == api.STSCD_AUTH_FAILED) {
					infoData.setData(infoData.MSG_TYPE_WARN, msgUtil.GET_MESSAGE("W001003"));
				// 認証APIステータスコードエラー
				} else {
//					infoData.setData(infoData.MSG_TYPE_ERROR, "[認証API実行エラー]" + "statusCode:" + res.statusCode() + "\nbody:" + res.body());
					infoData.setData(infoData.MSG_TYPE_ERROR, msgUtil.GET_MESSAGE("E002001", res.statusCode(), res.body()));
				}
				LOGGER_TRACE_END();
				return "login";
			}

		} catch (IOException | InterruptedException e) {
			LOGGER_STACKTRACE(INFO, "認証API例外発生", e);
//			infoData.setData(infoData.MSG_TYPE_ERROR, "[認証API例外発生]");
			infoData.setData(infoData.MSG_TYPE_ERROR, msgUtil.GET_MESSAGE("E002001"));
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			return "login";
		}
		LOGGER_TRACE_END();

		return "menu";

	}

}
