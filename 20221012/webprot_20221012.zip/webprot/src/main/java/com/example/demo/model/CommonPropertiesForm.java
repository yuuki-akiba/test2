package com.example.demo.model;

import lombok.Data;

@Data
public class CommonPropertiesForm {

	// プロパティ
	private CommonProperties prop = new CommonProperties();

	// --------------------
	// 画面制御
	// --------------------
//	// 処理結果
//	private String resultCd;
//	// メッセージ情報
//	private String messageInfo;
//	// エラー情報
//	private String errorInfo;

}
